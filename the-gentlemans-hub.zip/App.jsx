
import React from "react";
import { ShoppingBag, Glasses, Watch, Tie, User } from "lucide-react";

const ItemCard = ({ Icon, title, description }) => (
  <div className="bg-white rounded-2xl shadow p-6 text-center">
    <Icon className="h-10 w-10 mx-auto text-indigo-600" />
    <h2 className="text-xl font-semibold mt-4">{title}</h2>
    <p className="text-gray-500 mt-2">{description}</p>
    <button className="mt-4 bg-indigo-600 text-white py-2 px-4 rounded-xl hover:bg-indigo-700">
      Shop Now
    </button>
  </div>
);

export default function TheGentlemansHub() {
  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold text-gray-800 mb-2">The Gentleman's Hub</h1>
        <p className="text-gray-600">
          Perfumes, Studs, Ties, Caps, Glasses & Watches — All for the Modern Man
        </p>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        <ItemCard Icon={ShoppingBag} title="Perfumes" description="Signature scents to elevate your style." />
        <ItemCard Icon={User} title="Studs" description="Bold & elegant studs for men of class." />
        <ItemCard Icon={Tie} title="Ties" description="Premium ties for every formal occasion." />
        <ItemCard Icon={User} title="Caps" description="Stylish caps to complete your look." />
        <ItemCard Icon={Glasses} title="Glasses" description="Trendy eyewear for every face type." />
        <ItemCard Icon={Watch} title="Watches" description="Timeless watches for the gentleman." />
      </div>
    </div>
  );
}
